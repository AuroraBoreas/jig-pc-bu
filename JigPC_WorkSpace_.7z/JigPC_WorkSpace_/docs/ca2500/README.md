---
title: ca2500 sw manager
output: pdf document
---

# Overview
During Panel and TV optical R&D, there are plenty of data need be extracted from CA2500 software.<br>
Sure thing is the software's ```API``` exists there for bloody purchase.  <br>

It means our team has to do this laborous tasks repeatively without ```API``` purchase. <br>
This makes no sense at all.<br>

I'd like to change.<br>
There must be a way to do it automatically without ```API```. <br>

TLDR, automate this boring task without API to improve productivity.

## Thoughts of application design
The folling thoughts are cornerstone to build.
- simulate manual operations via programming (```Python```, ```VB```)
- name of any ca25 log file is **unique**
- name of any ca25 log file must have **specific characteristics** (PANEL, SET, ZOOMIN, 100IRE, 87IRE, 50IRE, 0IRE or combination)
- operations are same for each kind of evalation objects (<a>PANEL</a> or <a>SET</a> or <a>ZOOMIN</a> or <a>anything</a>)
- abstract these common operations and build a ```class``` for flexibilty
- inherite from the ```class``` and override some methods for different evaluation objects


## Automate with Python
<font color='blue'>ca25</font> software control (main window) <br>
<img src="ca2500_main.png" width="800" />

<font color='blue'>ca25</font> software control (sub window) <br>
<img src="ca2500_subwindow_select_tempates.png" width="800" />

<font color='blue'>Excel</font> software control (Data) <br>
<img src="excel_data.png" width="800" />

<font color='blue'>Excel</font> software control (Image) <br>
<img src="excel_img.png" width="800" />

# Usage
I had integrated this application with Excel VBA already. <br>
It's pretty simple to use now.

<font color='blue'>Excel integreated</font>(VBA) <br>
<img src="excel_integrated.png" width="800" />

# Disclaimer
This application works on **this computer** only. <br>
But its core is similar to other office automation stuff.

## Contact
Contact me if u have any questions. <br>
Email: liang.zhang@sony.com