import pyautogui

#cs2k, close, Point(x=951, y=116)

#ca25, topleft, Point(x=417, y=312)
#ca25, btmright, Point(x=788, y=521)
#ca25, data_row, scroll-bar, up, Point(x=340, y=191)
#ca25, data_row, scroll-bar, down, Point(x=340, y=700)
#ca25, copy_data_button, Point(x=688, y=142)
#ca25, copy_data_action, Point(x=688, y=253)
#ca25, color_switch_button, Point(x=843, y=142)
#ca25, ZoomIn, Point(x=369, y=181), Point(x=836, y=648)

print(pyautogui.position())
