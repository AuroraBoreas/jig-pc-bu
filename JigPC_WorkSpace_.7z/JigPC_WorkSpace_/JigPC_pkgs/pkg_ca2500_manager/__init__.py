__all__ = [
    'CA2500_data_extractor_core'
]