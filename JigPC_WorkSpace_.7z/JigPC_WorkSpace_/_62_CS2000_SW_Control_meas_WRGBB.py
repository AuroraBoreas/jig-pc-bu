"""============================================
Automate CS2000 measurement @ZL, 2019
============================================"""
import time, pyttsx3
import tkinter as tk
from tkinter import messagebox
from JigPC_pkgs.pkg_cs2000_manager.CS2000_SW_Control import main_meas_IRE
from JigPC_pkgs.pkg_Windows_Sound_Manager import sound

def cs2k_mease_WRGB(sample_name):
    ##mute then toggle speaker on
    sound.Sound.mute()
    sound.Sound.volume_min()
    sound.Sound.volume_max()

    engine = pyttsx3.init()
    engine.say("Program is ready")
    engine.runAndWait()

    SCC_No = sample_name
    Ageing_Hour = 2
    IRE = 'WRGB'
    meas_time = 12
    CA_Mode = True
    User_PSG500_op_time = 3

    main_meas_IRE(meas_time, SCC_No, IRE, CA_Mode, User_PSG500_op_time, Ageing_Hour)
    engine.say("job done")
    engine.runAndWait()
    engine.stop()
    ##toggle sound off
    sound.Sound.mute()

if __name__=='__main__':
    root = tk.Tk()
    root.withdraw()
    samples = [
                'NH75_Panel_SCC0004490_Opt(SKC)', 
                'NB75_Panel_SCC0004150_Opt(SKC)',
               ]

    for sample in samples:
        messagebox.showinfo("cs2k Meas", message=f"{sample} Ready?")
        cs2k_mease_WRGB(sample_name=sample)

    root.destroy()