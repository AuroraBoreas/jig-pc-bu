---
title: cs2000 sw manager
output: pdf document
---

# Overview
During Panel and TV optical R&D, there are plenty of data need be extracted from CS2000 software.<br>
Sure thing is the software's ```API``` exists there for bloody purchase.  <br>

It means our team has to do this laborous tasks repeatively without ```API``` purchase. <br>
This makes no sense at all.<br>

I'd like to change.<br>
There must be a way to do it automatically without ```API```. <br>

TLDR, automate this boring task without API to improve productivity.

## Auto click art
<font color='blue'>cs2k</font> software control (main window) <br>
<img src="cs2000.png" width="800" />


# Usage
I had integrated this application with Excel VBA already. <br>
It's pretty simple to use now.

# Disclaimer
This application works on **this computer** only. <br>
But its core is similar to other office automation stuff.

## Contact
Contact me if u have any questions. <br>
Email: liang.zhang@sony.com