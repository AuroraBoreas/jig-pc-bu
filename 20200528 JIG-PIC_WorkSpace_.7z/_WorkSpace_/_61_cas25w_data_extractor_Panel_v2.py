import tkinter as tk
from tkinter import messagebox
from CA2500_package.CA2500_data_extractor_base import main as panel_datainfo_extractor, CA2500_Extractor

# class CA2500_Extractor_SpecialPanel(CA2500_Extractor):
#     def verify_data_name_img(self, dn):
#         """verify data name: filter ca2500 log file based on wanted and NotWanted conditions"""
#         dn = dn.upper()
#         if any(i in dn for i in self.img_notwanted):
#             return False
#         else:
#             return any(i in dn for i in self.img_wanted)

if __name__=='__main__':
    root = tk.Tk()
    root.withdraw()

    #CAUTION: user must set up ca2500 first, including reference tab, colorful, range
    messagebox.showinfo("Extract DataInfo", message="Adjust CA2500 pls") #wait till user adjusts CA2500

    ## get a specific panel
    # extractor1 = CA2500_Extractor_SpecialPanel()
    # extractor1.data_wanted = ['100IRE', '50', 'SCC0000004']
    # extractor1.data_notwanted = ['SET', 'ZOOMIN', 'SCC0000011', 'SCC0000007']
    # extractor1.img_wanted = ['100IRE', '50', 'SCC0000004']
    # extractor1.img_notwanted = ['SET', 'ZOOMIN', 'SCC0000011', 'SCC0000007']
    # extractor1.main_get_data()
    # extractor1.main_get_img() 

    ## default setting
    panel_datainfo_extractor()

    messagebox.showinfo("Extract DataInfo", message="All Done") #wait till user adjusts CA2500
    root.destroy()